#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import re

for ligne in sys.stdin:
    ligne = ligne.strip()
    mots = re.findall(r'\w+', ligne.lower())
    for mot in mots:
        print("{0}\t{1}".format(mot, 1))
