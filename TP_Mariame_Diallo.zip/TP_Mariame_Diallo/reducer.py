#!/usr/bin/env python3

# -*- coding: utf-8 -*-

import sys

frequence_mots = {}

for ligne in sys.stdin:
    mot, compte = ligne.strip().split('\t')
    compte = int(compte)

    if mot in frequence_mots:
        frequence_mots[mot] += compte
    else:
        frequence_mots[mot] = compte

for mot, frequence in frequence_mots.items():
    print("{0}\t{1}".format(mot, frequence))
